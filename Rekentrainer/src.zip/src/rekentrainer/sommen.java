package rekentrainer;

public class sommen {
    int som;
    int antwoord;
    public sommen(int som, int antwoord) {
        this.som = som;
        this.antwoord = antwoord;
    }
}
